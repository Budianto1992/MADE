package com.budianto.moviejetpackpro.core.util

class Constant {

    companion object{
        const val IMAGE_PATH = "https://image.tmdb.org/t/p/w185/"
        const val BASE_URL = "https://api.themoviedb.org/3/"
        const val API_KEY = "406366e1df2dd0c7cf2443e4c9b88c18"
    }
}